
import torch
import transformers
import pandas as pd
import numpy as np
import torch
import os
import sys
import torch.nn as nn
from tqdm import tqdm
from sklearn.metrics import roc_auc_score, precision_score, recall_score, precision_recall_curve, auc
from focalloss import *

from transformers import AutoModel
from transformers import AutoTokenizer
#seyonec/PubChem10M_SMILES_BPE_450k
from transformers import RobertaModel,BertModel

model = RobertaModel.from_pretrained('../roberta-base')

tokenizer = AutoTokenizer.from_pretrained('../roberta-base')

RANDOM_SEED = 42
np.random.seed(RANDOM_SEED)
torch.manual_seed(RANDOM_SEED)

train = pd.read_csv('../train.csv', sep='\t')
test = pd.read_csv('../test.csv', sep='\t')
sub = pd.read_csv('../sample_submit.csv')

# 拼接title与abstract
train['text'] = train['title'] + ' ' + train['abstract']
test['text'] = test['title'] + ' ' + test['abstract']

label_id2cate = dict(enumerate(train.categories.unique()))
label_cate2id = {value: key for key, value in label_id2cate.items()}

train['label'] = train['categories'].map(label_cate2id)

train = train[['text', 'label']]
train_y = train["label"]

index = np.random.permutation(range(len(train)))
train_data = train.iloc[index[:int(0.9*len(train))]].reset_index(drop = True)
val_data = train.iloc[index[int(0.9*len(train)):]].reset_index(drop = True)
num = list(train.groupby('label').size().values)
num = np.array(num)/min(num)
weight = list(1/num)
from torch.utils.data import Dataset,DataLoader,TensorDataset
class My_dataset(Dataset):
    def __init__(self,data_len):
        super(My_dataset,self).__init__()
            
        self.data = data_len
    def __getitem__(self,idx):

        return self.data[idx]#mol,'_'.join(pro),label#torch.tensor(),torch.tensor(),torch.tensor(tss),torch.tensor(feats,dtype = torch.float32)
    def __len__(self):
        return len(self.data)

val_dataloader = DataLoader(list(range(len(val_data))),batch_size = 8,num_workers = 0,shuffle = True)
train_dataloader = DataLoader(list(range(len(train_data))),batch_size = 8,num_workers = 0,shuffle = True)
test_dataloader = DataLoader(list(range(len(test))),batch_size = 8,num_workers = 0,shuffle = False)

class MLP(nn.Module):
    def __init__(self,dim_in,dim_hidden,dim_out):
        super(MLP,self).__init__()
        self.fc_1 = nn.Linear(dim_in,dim_hidden)
        self.fc_2 = nn.Linear(dim_hidden,dim_out)
    def forward(self,data):
        return self.fc_2(torch.relu(self.fc_1(data)))#return logits for crosss_entry
device = 'cuda:7' if torch.cuda.is_available() else 'cpu'
modelmlp = MLP(768,768*2,39)
# Loss = torch.nn.CrossEntropyLoss(weight = torch.tensor(weight).view(39,).float().to(device))
Loss = FocalLoss(gamma = 2,alpha = weight)#weight be a list 
optimizer = torch.optim.AdamW([{'params':modelmlp.parameters()},{'params':model.parameters()}],lr = 4e-5,amsgrad = True)
epochs = 100
# device = 'cuda:4' if torch.cuda.is_available() else 'cpu'
print('device',device)
best_acc = 0
patience = 5
counter = 0
train_loss_all = []
val_loss_all = []
train_acc_all = []
val_acc_all = []
for epoch in range(1,epochs+1):
    print('strating training!!')
    train_loss = []
    val_loss = []
    #test_loss = 0
    S = []
    T = []
    S_train = []
    T_train = []
    modelmlp.to(device)
    modelmlp.train()
    model.to(device)
    model.train()
#     pbar = tqdm(train_dataloader)
    for batch in train_dataloader:
        batch_data = train_data.iloc[batch].copy()
        #batch_data[1] = batch_data[1].apply(lambda x : re.sub(r"[UZOB]", "X", x))
        # mol_batch = list(batch_data[0].values)
        # pro_batch = list(batch_data[1].values)
        text_batch = list(batch_data['text'].values)
        label_batch = torch.tensor(list(batch_data['label'].values))
#         model_mol.eval()
#         model_pro.eval()
#         with torch.no_grad():
            #size = [bs,768]
        tokenizer_input = tokenizer(text_batch,return_tensors = 'pt',padding = True,max_length = 512,truncation = True)
        input_ids,att_mask = tokenizer_input['input_ids'],tokenizer_input['attention_mask']
        model_out = model(input_ids.to(device),att_mask.to(device))['pooler_output']
            # #size = [bs,1024]
            # pro_out = model_pro(**tokenizer_pro(pro_batch,return_tensors = 'pt',padding = True,max_length = 1500,truncation = True))['pooler_output']
        # model_input = torch.cat([mol_out,pro_out],dim = 1)#bs,1792
        model_out = modelmlp(model_out.to(device))
        loss = Loss(model_out,label_batch.to(device))
        scores = torch.softmax(model_out,dim = 1).cpu().detach().numpy()
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        train_loss.append(loss.item())
#         pbar.update()
#         print('train_loss: {}'.format(np.sum(train_loss)/len(train_loss)))
        S_train.extend(scores)
        T_train.extend(label_batch.cpu().detach().numpy())
#     AUC = roc_auc_score(T_train, S_train,multi_class='ovo')
#     tpr, fpr, _ = precision_recall_curve(T_train, S_train)
#     PRC = auc(fpr, tpr)
    #print(AUC, PRC)
    train_loss_all.append(np.sum(train_loss)/len(train_loss))
    train_acc = np.sum(np.argmax(S_train,axis = 1) == T_train)/len(T_train)
    train_acc_all.append(train_acc)
    print('train_loss:, ',np.sum(train_loss)/len(train_loss),'train_acc: ',train_acc) 
    
#val state
    model.eval()
    modelmlp.eval()
#     pbar = tqdm(val_dataloader)
    for batch in val_dataloader:

        batch_data = val_data.iloc[batch].copy()
        #batch_data[1] = batch_data[1].apply(lambda x : re.sub(r"[UZOB]", "X", x))
        # mol_batch = list(batch_data[0].values)
        # pro_batch = list(batch_data[1].values)
        text_batch = list(batch_data['text'].values)
        label_batch = torch.tensor(list(batch_data['label'].values))
        with torch.no_grad():
            #size = [bs,768]
            # mol_out = model_mol(**tokenizer_mol(mol_batch,return_tensors = 'pt',padding = True,max_length = 512,truncation = True))['pooler_output']
            #size = [bs,1024]
            tokenizer_input = tokenizer(text_batch,return_tensors = 'pt',padding = True,max_length = 512,truncation = True)
            input_ids,att_mask = tokenizer_input['input_ids'],tokenizer_input['attention_mask']
            model_out = model(input_ids.to(device),att_mask.to(device))['pooler_output']
            # model_input = torch.cat([mol_out,pro_out],dim = 1)#bs,1792
            model_out = modelmlp(model_out.to(device))
            loss = Loss(model_out,label_batch.to(device))
            #scores = torch.softmax(model_out,dim = 1)[:,1]
            val_loss.append(loss.item())
            scores = torch.softmax(model_out,dim = 1).cpu().detach().numpy()
            S.extend(scores)
            T.extend(label_batch.cpu().detach().numpy())
#             pbar.set_description('val_loss: {}'.format(np.sum(val_loss)/len(val_loss)))
#             pbar.update()
#     AUC = roc_auc_score(T, S,multi_class='ovo')
#     tpr, fpr, _ = precision_recall_curve(T, S)
#     PRC = auc(fpr, tpr)
    val_acc = np.sum(np.argmax(S,axis = 1) == T)/len(T)
    counter +=1
    val_loss_all.append(np.sum(val_loss)/len(val_loss))
    val_acc_all.append(val_acc)
    print('val_loss: ',np.sum(val_loss)/len(val_loss),'val_acc: ',val_acc) 
    if val_acc > best_acc:
        counter = 0
        best_acc = val_acc
        torch.save({'modelmlp':modelmlp.state_dict(),
                    'model':model.state_dict(),
                   'epoch':epoch,
                   'optimizer':optimizer.state_dict(),
                   'best_acc':best_acc,
                   'val_loss_all':val_loss_all,
                   'train_loss_all':train_loss_all,
                   'train_acc_all':train_acc_all,
                   'val_acc_all':val_acc_all},'./my_pretrain_model_best_facalloss_lr-4e-5.pth')
    if counter > patience:
        print('early stop in %d'%epoch)
        torch.save({'modelmlp':modelmlp.state_dict(),
                    'model':model.state_dict(),
                   'epoch':epoch,
                   'optimizer':optimizer.state_dict(),
                   'best_acc':best_acc,
                   'val_loss_all':val_loss_all,
                   'train_loss_all':train_loss_all,
                   'train_acc_all':train_acc_all,
                   'val_acc_all':val_acc_all},'./my_pretrain_model_early_facalloss_lr-4e-5.pth')
        break
#test 
# model.eval()
# modelmlp.eval()
bestmodel = torch.load('./my_pretrain_model_best_facalloss_lr-4e-5.pth')
model.load_state_dict(bestmodel['model'])
model.eval()
modelmlp.load_state_dict(bestmodel['modelmlp'])
modelmlp.eval()
# pbar = tqdm(test_dataloader)
predictions = []
for batch in test_dataloader :

    batch_data = test.iloc[batch].copy()
    #batch_data[1] = batch_data[1].apply(lambda x : re.sub(r"[UZOB]", "X", x))
    # mol_batch = list(batch_data[0].values)
    # pro_batch = list(batch_data[1].values)
    text_batch = list(batch_data['text'].values)
    #label_batch = torch.tensor(list(batch_data['label'].values))
    with torch.no_grad():
        #size = [bs,768]
        # mol_out = model_mol(**tokenizer_mol(mol_batch,return_tensors = 'pt',padding = True,max_length = 512,truncation = True))['pooler_output']
        #size = [bs,1024]
        tokenizer_input = tokenizer(text_batch,return_tensors = 'pt',padding = True,max_length = 512,truncation = True)
        input_ids,att_mask = tokenizer_input['input_ids'],tokenizer_input['attention_mask']
        model_out = model(input_ids.to(device),att_mask.to(device))['pooler_output']
        # model_input = torch.cat([mol_out,pro_out],dim = 1)#bs,1792
        model_out = modelmlp(model_out.to(device))
#             loss = Loss(model_out,label_batch.to(device))
        #scores = torch.softmax(model_out,dim = 1)[:,1]
#         val_loss.append(loss.item())
        scores = torch.softmax(model_out,dim = 1).cpu().detach().numpy()
        prediction = np.argmax(scores,axis = 1)
        predictions.extend(prediction)
#         pbar.update()
sub['categories'] = predictions
sub['categories'] = sub['categories'].map(label_id2cate)
sub.to_csv('./submit_facalloss_4e_5.csv', index=False)
print('done')





